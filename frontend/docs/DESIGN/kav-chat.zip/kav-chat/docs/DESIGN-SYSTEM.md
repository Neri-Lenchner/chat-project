# KAV — Design System

Design system for the chat application described in `SPECV2-FRONT.md`.
This document is the single source of truth for anything visual. If a value is not
here, derive it from the tokens — never invent a new hard-coded value.

- **Reference implementation:** the HTML prototype in the project root (`index.html`, `login.html`, `register.html`, `home.html`, `new-chat.html`, `chat.html`).
- **Token source:** `css/tokens.css` — port as-is to the React app (`src/styles/tokens.css`, imported once in `main.tsx`).
- **Language / direction:** Hebrew, RTL. UI strings in Hebrew, code and identifiers in English.

---

## 1. Product identity

**Name:** קו (KAV) — "line". A phone line, a line of text, and the vertical rule that
runs through every screen.

**Concept:** identity in this product *is* a phone number. There are no passwords and no
usernames. So numbers are treated as a design material: every number in the UI —
phone, time, date, unread count — is set in tabular monospace. Everything else is sans.

**The signature element:** the *rail* — a hairline vertical rule.
- In the conversation screen it runs down the centre of the thread and carries every message timestamp. Bubbles hang off it on both sides.
- In the brand panel of the auth screens it becomes a field of vertical lines (a signal waveform).
- In lists it appears as a 3px marker on the leading edge of the hovered row.

Spend boldness here and nowhere else. Everything around the rail stays quiet:
white surfaces, hairline borders, generous whitespace.

**Tone of voice:** direct, second person, sentence case, no exclamation marks, no apologies.
Errors state what happened and what to do (`לא ניתן להתחבר. בדוק את מספר הטלפון ונסה שוב.`).
A button's label is repeated by the state it produces (`מחיקה` → `השיחה נמחקה`).

---

## 2. Color

Light mode only. All values live in `css/tokens.css`. Use **semantic** tokens in components;
primitives exist only to define the semantic layer.

### 2.1 Primitives

| Ramp | Tokens | Notes |
| --- | --- | --- |
| Brand (tekhelet azure-indigo) | `--brand-50 #EEF1FF` · `--brand-100 #DFE4FF` · `--brand-200 #C2CBFF` · `--brand-300 #98A6F8` · `--brand-400 #6C7DEF` · `--brand-500 #3B54DC` · `--brand-600 #2B3FBB` · `--brand-700 #213196` · `--brand-900 #16205F` | 500 = actions, 700 = brand panel |
| Ink | `--ink-900 #0E1430` · `--ink-800 #1B2244` · `--ink-700 #333C63` · `--ink-600 #4E5779` · `--ink-500 #6B7492` · `--ink-400 #8B93AE` · `--ink-300 #AFB6CB` | 900 also = outgoing bubble |
| Neutral | `--paper #F1F3FA` · `--surface #FFFFFF` · `--surface-2 #F7F8FC` · `--surface-3 #EDF0F8` · `--line #E3E7F2` · `--line-2 #D2D8EA` | |
| Accent (saffron) | `--gold-500 #EFAE3A` · `--gold-600 #C98A1C` · `--gold-100 #FCF0D8` | unread only |
| Success | `--mint-500 #1F9C7C` · `--mint-100 #E3F5EF` | |
| Danger | `--rose-500 #D33C57` · `--rose-600 #B32B44` · `--rose-100 #FBE7EB` · `--rose-200 #F5C9D1` | |

### 2.2 Semantic tokens

| Token | Value | Used for |
| --- | --- | --- |
| `--color-bg` | `--paper` | app background |
| `--color-surface` | `--surface` | cards, rows, bubbles (incoming), app bar, composer |
| `--color-surface-alt` | `--surface-2` | composer field, hover fills |
| `--color-border` | `--line` | all hairlines |
| `--color-border-strong` | `--line-2` | input borders |
| `--color-text` | `--ink-900` | headings, primary text |
| `--color-text-soft` | `--ink-600` | secondary text |
| `--color-text-muted` | `--ink-400` | timestamps, placeholders, meta |
| `--color-primary` | `--brand-500` | primary buttons, focus, links, active nav |
| `--color-primary-soft` | `--brand-50` | active nav background, empty-state art |
| `--color-accent` | `--gold-500` | unread badge only |
| `--color-danger` | `--rose-500` | destructive actions, field errors |
| `--bubble-out-bg` / `--bubble-out-fg` | `--ink-900` / `#FFF` | outgoing message |
| `--bubble-in-bg` / `--bubble-in-fg` | `--surface` / `--ink-800` | incoming message |
| `--focus-ring` | `0 0 0 3px var(--brand-200)` | focus-within on fields |

**Rules**
1. Brand blue is for *interaction*, never for decoration and never for message bubbles.
2. Saffron appears at most once per screen (unread count). If everything is highlighted, nothing is.
3. Never use pure `#000` or a pure neutral gray — all grays are indigo-tinted ink.
4. Avatar chips are assigned deterministically from the contact name (`chipOf()` → 1–6, tokens `--chip-N-bg` / `--chip-N-fg`). Never random.

### 2.3 Contrast
Body text on paper ≥ 12:1. `--color-text-muted` on `--color-surface` ≈ 4.6:1 — do not use it below 11px or for anything that isn't a timestamp or meta label.

---

## 3. Typography

Loaded from Google Fonts:
`IBM+Plex+Sans+Hebrew:300,400,500,600,700` · `IBM+Plex+Mono:400,500,600` · `Suez+One`.

| Role | Token | Family | Where |
| --- | --- | --- | --- |
| Display | `--font-display` | Suez One | wordmark, screen titles, empty-state titles. **Nothing else.** |
| Body | `--font-sans` | IBM Plex Sans Hebrew | everything |
| Utility | `--font-mono` | IBM Plex Mono | times, dates, phone numbers, counts, eyebrows |

### Scale

| Token | px | Use |
| --- | --- | --- |
| `--fs-2xs` | 11 | rail timestamps, eyebrows |
| `--fs-xs` | 12 | badges, list meta |
| `--fs-sm` | 13 | hints, error text |
| `--fs-md` | 14 | secondary body, dialog text |
| `--fs-base` | 15 | body, inputs, buttons, bubbles |
| `--fs-lg` | 17 | row titles, dialog title |
| `--fs-xl` | 20 | chat screen title |
| `--fs-2xl` | 24 | screen titles |
| `--fs-3xl` | 32 | auth headline |
| `--fs-4xl` | 44 | wordmark (mobile) |
| `--fs-5xl` | 72 | brand panel wordmark |

Weights: 300 tagline · 400 body · 500 emphasis · 600 titles/buttons · 700 rare.
Line heights: `--lh-tight 1.15` (display), `--lh-snug 1.35` (list rows), `--lh-normal 1.55` (body).

**Rules**
- Every number renders with `font-variant-numeric: tabular-nums` so columns of times never jitter. `time` and `.num` do this automatically.
- Eyebrows are mono, uppercase, `--ls-caps`, `--color-text-muted`. Use them to label a screen's context, not to decorate.
- Never set a font-size outside the scale.

---

## 4. Spacing, radii, elevation, motion

**Spacing** — 4px base: `--sp-1 4` `--sp-2 8` `--sp-3 12` `--sp-4 16` `--sp-5 20` `--sp-6 24` `--sp-8 32` `--sp-10 40` `--sp-12 48` `--sp-16 64`.
Padding inside a row/card is `--sp-3` block / `--sp-4` inline. Gaps between list rows: `--sp-2`. Screen gutters: `--sp-6` (desktop), `--sp-4` (mobile).

**Radii** — `--r-xs 6` `--r-sm 8` `--r-md 12` (buttons, inputs) `--r-lg 16` (rows) `--r-xl 20` (cards, dialog) `--r-2xl 26` (composer) `--r-full` (badges, avatars in rail, send button) `--r-bubble 18` with `--r-bubble-tail 5` on the corner that faces the sender's side.
Avatars are **squircles** (`border-radius: 34%`), not circles. This is deliberate — keep it.

**Elevation** — four levels only:
`--shadow-1` resting surfaces · `--shadow-2` hover · `--shadow-3` dialog/toast/floating · `--shadow-4` modal.
All shadows are tinted with `rgba(14,20,48,…)`. Never use a black shadow.

**Motion** — `--dur-fast 120ms` (press) · `--dur 200ms` (hover, color) · `--dur-slow 340ms` (enter/exit) · `--dur-press 650ms` (long-press to delete) · `--ease` for movement, `--ease-out` for entrances.
Animations in the system: `bubble-in`, `dialog-in`, `toast-in/out`, `field-in`, `row-out`, `shimmer`, `nudge` (invalid composer), `wave` (brand panel).
`prefers-reduced-motion` collapses all durations to 1ms via the token block — do not add animations that bypass tokens.

**Layout dimensions** — `--h-control 48` · `--h-control-sm 36` · `--h-header 72` · `--nav-w 76` · `--nav-h-mobile 64` · `--avatar-sm/md/lg 36/46/56` · `--w-list 760` · `--w-thread 900` · `--w-form 400` · `--rail-gutter 76`.

Everything that a user clicks is 48px tall, or 36px for a secondary/icon control. There is no third height.

---

## 5. Layout & shell

```
┌───────────────────────────────────────── RTL ─────────────┐
│ [main column]                                    [rail]   │
│ ┌───────────────────────────────────────┐  ┌──┐           │
│ │ appbar  (sticky, 72px, blurred)       │  │לוגו│          │
│ ├───────────────────────────────────────┤  │שיחות│         │
│ │ scroll area                           │  │חדשה │         │
│ │   container (max 760 / 900, centred)  │  │ ⋮  │          │
│ │                                       │  │משתמש│         │
│ │                                       │  │יציאה│         │
│ └───────────────────────────────────────┘  └──┘           │
└───────────────────────────────────────────────────────────┘
```

- `.app` = flex row. The rail is **first in the DOM** so it renders on the right in RTL.
- `.main` is `100dvh` with a sticky `.appbar`, a flexible `.scroll`, and (chat only) a fixed `.composer`.
- Content is centred with `.container` (`--w-list`) or `.container--thread` (`--w-thread`).
- **Breakpoint: 860px.** Below it the rail becomes a fixed bottom bar (`--nav-h-mobile`), tooltips are dropped, and gutters shrink to `--sp-4`.
- **Breakpoint: 720px.** Below it the thread rail is hidden and messages fall back to a single-column layout with the timestamp under the bubble.

There are only these two breakpoints. Do not add more.

### RTL rules
- Use logical properties everywhere: `inset-inline-start`, `padding-inline`, `margin-block`, `border-start-start-radius`. No `left` / `right` / `padding-left`.
- Directional icons (back arrow, send, logout) carry `.icon--flip`, which mirrors them under `[dir="rtl"]`.
- Phone numbers are LTR islands: `dir="ltr"` + `text-align: start` inside an RTL parent.
- Outgoing messages sit on the inline-end side (visually left in Hebrew); incoming on inline-start.

---

## 6. Components

Each component is implemented in `css/components.css`. React components should render the same
class names so the CSS ports without a rewrite.

### 6.1 Button — `.btn`
Variants: `--primary`, `--secondary`, `--ghost`, `--danger`. Modifiers: `--block`, `--sm`, `--icon`, `--round`.

| State | Treatment |
| --- | --- |
| hover | one step darker (`--color-primary-hover`) or `--color-surface-alt` for quiet variants |
| active | `translateY(1px)` |
| focus-visible | 2px `--color-primary` outline, 2px offset |
| disabled | `opacity .55`, no transform, `cursor: not-allowed` |
| loading | `data-loading="true"` → leading spinner replaces `.btn__icon`, pointer events off, `aria-busy` |

Loading is the mechanism that prevents double submit (spec §15). Set it before the request and clear it in `finally`.

### 6.2 Field — `.field`
Anatomy: `.field__label` (+ `.req`) → `.field__control` (icon + input) → `.field__error` → `.field__hint`.

- Height `--h-control`, radius `--r-md`, border `--color-border-strong`.
- `:focus-within` → brand border + `--focus-ring`; the leading icon turns brand.
- Error: set `data-invalid="true"` on `.field` → red border, `--color-danger-soft` fill, red icon, and `.field__error` animates in with an alert icon. The input also gets `aria-invalid="true"`.
- Phone inputs use `.input--tel` (LTR, mono, `letter-spacing .06em`, digits only on input).

**Validation timing:** validate on submit, and on `blur` only when the field is non-empty. Clear the error on the first keystroke. Never validate on every keystroke — it punishes people mid-typing.

### 6.3 Banner — `.banner`
Form-level / API errors, rendered above the first field. Variants `--error`, `--info`, `--success`.
Structure: icon + `.banner__title` (what happened) + `.banner__text` (what to do). `role="alert"`.

### 6.4 Toast — `.toast`
Transient feedback for actions that are not tied to a form (delete failed, message send failed).
Dark `--ink-900` surface, bottom-centre, auto-dismiss after 5s, manual close, `aria-live="polite"`.
Never use a toast for a validation error that belongs to a field.

### 6.5 Dialog — `.dialog` inside `.overlay`
Used for destructive confirmation (spec §8) and logout.
420px max, radius `--r-xl`, `--shadow-4`, overlay is `ink-900 @42%` + 3px blur.
Two equal-width buttons: cancel (`--secondary`) then confirm (`--danger`).
Focus moves to the confirm button on open, `Esc` cancels, `Tab` is trapped, click on the overlay cancels.

### 6.6 List row — `.row-item`
One anatomy serves both conversations and contacts:
`avatar` → `.row-item__body` (title + subtitle, both truncated) → `.row-item__side` (time + badge) → `.row-item__action` (appears on hover).

- Hover: stronger border, `--shadow-2`, and the 3px brand rail on the leading edge.
- `.is-unread`: subtitle becomes `--color-text` / weight 500, time turns `--gold-600`, badge appears.
- **Long-press to delete** (spec §8): `pointerdown` adds `.is-pressing`, which fills the row with `--color-danger-soft` over `--dur-press`. The fill *is* the progress indicator. `pointerup` / `pointerleave` cancels. On completion the dialog opens and the following `click` is suppressed.
- Keyboard equivalents are mandatory: `Enter`/`Space` opens, `Delete` opens the confirm dialog, and `.row-item__action` (trash icon button) is reachable by Tab.
- Removal animates with `row-out` (340ms) before the list re-renders.

### 6.7 Message — `.msg`
```
grid-template-columns: 1fr  var(--rail-gutter)  1fr
      incoming bubble │  timestamp   │  outgoing bubble
```
The centre column is the rail gutter; `.thread__rail` is absolutely positioned at 50% of `.thread`.
Bubbles can never cross the rail — that constraint is what makes the screen legible.

- Incoming: white, hairline border, `--shadow-1`, tail on `border-start-start-radius`.
- Outgoing: `--ink-900`, white text, tail on `border-end-end-radius`.
- Enter animation: `bubble-in`, 340ms.
- Timestamp: mono 11px, `--color-text-muted`, aligned to the bottom of its bubble. Outgoing timestamps carry a mint check icon.
- Day dividers (`.daybreak`) sit **on** the rail: a pill with `--color-bg` background that interrupts the line. Labels: `היום` / `אתמול` / `DD/MM/YYYY`.

### 6.8 Composer — `.composer`
Fixed to the bottom of `.main`, white, top hairline. Pill field (`--r-2xl`) + round 48px send button.
- Textarea auto-grows to 132px, then scrolls.
- `Enter` sends, `Shift+Enter` inserts a newline.
- Empty (after `trim()`) → `data-invalid="true"` on `.composer`: the field turns red, `nudge` plays once, and `.composer__error` appears. No request is made (spec §17).
- The field is cleared **only** after a successful response. On failure the text stays and a toast explains why.

### 6.9 Empty / error / skeleton states
- `.empty`: squircle art tile (brand-soft, or danger-soft for errors) + display title + one sentence + one action. An empty screen always offers the next step.
- Error variant adds a `נסה שוב` button wired to the same loader.
- `.skeleton`: shimmer placeholders matching the real layout (4 rows for the list, 3 bubbles for a thread). Show skeletons only on a first load — never when the data is already in Redux (spec §22).

### 6.10 Navigation rail — `.rail`
Logo → `שיחות` → `שיחה חדשה` → spacer → divider → user avatar → `התנתקות`.
Active item: `aria-current="page"` → brand-soft fill + a 3px brand rail on the outer edge.
Tooltips are CSS-only via `data-tip` and are hidden on mobile.

---

## 7. Iconography

Inline SVG sprite (`js/icons.js` → `src/components/Icon.tsx`). 24×24 grid, `fill: none`,
`stroke: currentColor`, `stroke-width: 1.6` (1.8 at 16px), round caps and joins.

| Icon | Used for |
| --- | --- |
| `chats` | rail nav, empty state |
| `plus` | new conversation |
| `users` / `user` / `id` | contacts, profile, name fields |
| `phone` | phone inputs, room meta |
| `send` | composer (flipped in RTL) |
| `trash` | delete room, confirm dialog art |
| `search` | contacts search |
| `back` | app bar back (flipped in RTL) |
| `alert` | field errors, banners, error toasts |
| `check` | delivered messages, success toasts |
| `close` | dismiss toast |
| `info` | info banners |

Sizes: `.icon` 20px, `.icon--sm` 16px, `.icon--lg` 24px, `.icon--xl` 32px. Never scale outside these.
Icons never appear alone in a primary action unless the control also carries `aria-label`.

---

## 8. Screen blueprints

### 8.1 Login (`login.html`, spec §6)
Split layout: brand panel `42%` / form panel. Brand panel = `--brand-700`, wordmark in Suez One,
tagline in weight 300 brand-200, and the animated line field anchored to the bottom.
Form: eyebrow → title → sub → banner slot → phone field → primary block button → switch link.
Below 860px the panel collapses to a 208px header strip.

### 8.2 Register (`register.html`, spec §5)
Identical shell, three fields (`שם פרטי`, `שם משפחה`, `טלפון`), each independently validated.
The first invalid field receives focus on submit.

### 8.3 Conversations (`home.html`, spec §7–8)
App bar: title `שיחות` + mono meta (`5 שיחות · 7 לא נקראו`) + primary `שיחה חדשה`.
Body: `.list` of `.row-item`, sorted by `lastMessageAt` descending.
Time formatting (spec §7.2): today → `HH:MM`, otherwise → `DD/MM/YYYY`.

### 8.4 New conversation (`new-chat.html`, spec §9)
Back button + title, a pill search field, then contacts grouped by first letter (`.list__label`).
Contacts that already have a room show a quiet `שיחה קיימת` badge and navigate to it instead of
creating a duplicate. Creating shows a spinner in that row only, never a full-screen loader.

### 8.5 Conversation (`chat.html`, spec §10–12)
App bar: back + avatar + name + phone (mono, LTR) + delete action.
Thread with the centre rail; composer pinned to the bottom; scroll jumps to the newest message on
load and animates to it after a successful send.

---

## 9. Accessibility floor

Non-negotiable, and already met by the prototype:

- Visible focus on every interactive element (`:focus-visible`, 2px brand outline).
- Every icon-only control has `aria-label`; decorative SVGs have `aria-hidden="true"`.
- Errors use `role="alert"`; live regions use `aria-live="polite"`.
- The dialog is `role="dialog" aria-modal="true"`, traps Tab, closes on `Esc`.
- Long-press has keyboard and pointer alternatives (`Delete`, trash button, context menu).
- Touch targets ≥ 44px.
- `prefers-reduced-motion` is respected globally.
- Text is never below 11px, and 11px is reserved for timestamps.

---

## 10. Porting to React + TypeScript

The prototype is deliberately structured to map 1:1 onto the folder layout in spec §25.

| Prototype | React |
| --- | --- |
| `css/tokens.css` | `src/styles/tokens.css` — import once, never edit per-component |
| `css/base.css`, `css/components.css` | `src/styles/` — or split per component, keeping identical class names |
| `js/icons.js` | `src/components/Icon/Icon.tsx` (sprite mounted once in `App.tsx`) |
| `Shell.rail()` | `src/components/NavRail/NavRail.tsx` |
| `confirmDialog()` | `src/components/ConfirmDialog/ConfirmDialog.tsx` |
| `toast()` | `src/components/Toast/ToastHost.tsx` + a `useToast()` hook |
| `Validate` | `react-hook-form` rules (`register('phone', { required, pattern })`) |
| `setFieldError` / `showBanner` | RHF `formState.errors` + the slice's `error` field |
| `api.call()` | `src/api/*.ts` with axios |
| `Store` | `userSlice` / `roomSlice` / `messageSlice` + `localStorage` util |
| `Demo` panel | delete — prototype only |

**Rules that survive the port**
1. `isLoading` lives in the slice, and the submit button reads it. One source of truth for "busy".
2. Skeletons render only when `isLoaded === false`. Data already in Redux never re-triggers a loader (spec §22).
3. On success, mutate Redux locally — no follow-up `GET` (spec §20).
4. On failure, the UI does not change optimistically: the row stays, the text stays in the composer, the user stays on the screen.
5. Friendly Hebrew error copy is decided in the slice, not in the component, so the same failure reads identically everywhere.

---

## 11. Copy inventory

Keep these strings in one place (`src/constants/strings.ts`) so wording never drifts.

| Key | Hebrew |
| --- | --- |
| `auth.login.title` | התחברות |
| `auth.register.title` | הרשמה |
| `field.required` | שדה חובה. |
| `field.phone.invalid` | מספר הטלפון אינו תקין. לדוגמה: 0501234567 |
| `error.login` | לא ניתן להתחבר. בדוק את מספר הטלפון ונסה שוב. |
| `error.register.taken` | המספר כבר רשום במערכת. |
| `error.rooms.load` | לא ניתן לטעון את השיחות. נסה שוב. |
| `error.messages.load` | לא ניתן לטעון את ההודעות. נסה שוב. |
| `error.message.send` | לא ניתן לשלוח את ההודעה. נסה שוב. |
| `error.room.delete` | לא ניתן למחוק את השיחה. נסה שוב. |
| `error.generic` | אירעה שגיאה. נסה שוב. |
| `validation.empty-message` | לא ניתן לשלוח הודעה ריקה. |
| `dialog.delete.title` | האם למחוק את השיחה? |
| `dialog.delete.confirm` | מחיקה |
| `dialog.delete.cancel` | ביטול |
| `empty.rooms.title` | הקו שלך שקט |
| `empty.messages.title` | אין עדיין הודעות |
| `action.retry` | נסה שוב |

---

## 12. What not to do

- Do not introduce a second accent color, a gradient background, or a shadow that isn't in the scale.
- Do not use Suez One for body text, buttons, or labels. It is a display face only.
- Do not put a timestamp inside a bubble on desktop — it belongs on the rail.
- Do not use physical CSS directions; RTL is the primary direction, not an afterthought.
- Do not show a spinner over content that is already in Redux.
- Do not add a full-screen loader for a row-level action.
- Do not write an error message that says only "שגיאה", and never surface a status code or stack trace.
