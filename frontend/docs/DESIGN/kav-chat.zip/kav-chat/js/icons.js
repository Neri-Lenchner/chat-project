/* ============================================================
   KAV · Icon sprite
   Stroke icons, 24px grid, 1.6 stroke. Use:
   <svg class="icon"><use href="#i-send"></use></svg>
   ============================================================ */

const KAV_ICONS = `
<svg xmlns="http://www.w3.org/2000/svg" style="display:none" aria-hidden="true">
  <symbol id="i-chats" viewBox="0 0 24 24">
    <path d="M20.5 11.4a8 8 0 0 1-8.6 8 8.2 8.2 0 0 1-3.5-.9L3.5 20l1.6-4.7a8 8 0 0 1 6.6-12.2 8 8 0 0 1 8.8 8.3Z"/>
    <path d="M9 11h.01M12 11h.01M15 11h.01"/>
  </symbol>
  <symbol id="i-plus" viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></symbol>
  <symbol id="i-users" viewBox="0 0 24 24">
    <circle cx="9.5" cy="8" r="3.2"/><path d="M3.5 20a6 6 0 0 1 12 0"/>
    <path d="M16 5.2a3.2 3.2 0 0 1 0 5.6M17.5 14.4A6 6 0 0 1 20.5 20"/>
  </symbol>
  <symbol id="i-user" viewBox="0 0 24 24"><circle cx="12" cy="8" r="3.4"/><path d="M4.8 20a7.2 7.2 0 0 1 14.4 0"/></symbol>
  <symbol id="i-logout" viewBox="0 0 24 24">
    <path d="M9.5 21H5.5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="m16 16.5 4.5-4.5L16 7.5"/><path d="M20.5 12h-11"/>
  </symbol>
  <symbol id="i-send" viewBox="0 0 24 24"><path d="M21.5 2.5 10.8 13.2"/><path d="m21.5 2.5-6.8 19-3.9-8.3-8.3-3.9 19-6.8Z"/></symbol>
  <symbol id="i-trash" viewBox="0 0 24 24">
    <path d="M3.5 6h17"/><path d="M8.5 6V4.2A1.2 1.2 0 0 1 9.7 3h4.6a1.2 1.2 0 0 1 1.2 1.2V6"/>
    <path d="M6 6.5 7 20a1.2 1.2 0 0 0 1.2 1h7.6A1.2 1.2 0 0 0 17 20l1-13.5"/><path d="M10.5 10.5v6M13.5 10.5v6"/>
  </symbol>
  <symbol id="i-phone" viewBox="0 0 24 24">
    <path d="M21 16.4v2.6a2 2 0 0 1-2.2 2 19.4 19.4 0 0 1-8.4-3 19 19 0 0 1-5.9-5.9 19.4 19.4 0 0 1-3-8.5A2 2 0 0 1 3.5 2h2.6a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L7.2 9.7a15.5 15.5 0 0 0 5.9 5.9l1.1-1.1a2 2 0 0 1 2.1-.5c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.9 2Z"/>
  </symbol>
  <symbol id="i-search" viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/></symbol>
  <symbol id="i-back" viewBox="0 0 24 24"><path d="m15 5-7 7 7 7"/></symbol>
  <symbol id="i-alert" viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 7.5v5.2M12 16.3h.01"/></symbol>
  <symbol id="i-check" viewBox="0 0 24 24"><path d="m4.5 12.8 5 5L19.5 6.5"/></symbol>
  <symbol id="i-close" viewBox="0 0 24 24"><path d="m6 6 12 12M18 6 6 18"/></symbol>
  <symbol id="i-sliders" viewBox="0 0 24 24">
    <path d="M5 21v-6M5 11V3M12 21v-9M12 8V3M19 21v-4M19 13V3"/>
    <path d="M2.5 15h5M9.5 12h5M16.5 17h5"/>
  </symbol>
  <symbol id="i-info" viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 16.5v-5M12 7.8h.01"/></symbol>
  <symbol id="i-id" viewBox="0 0 24 24">
    <rect x="3" y="5" width="18" height="14" rx="2.5"/><circle cx="8.5" cy="11.5" r="2"/>
    <path d="M5.5 16.5a3.4 3.4 0 0 1 6 0M14 10h4M14 14h2.5"/>
  </symbol>
</svg>`;

document.addEventListener('DOMContentLoaded', () => {
  document.body.insertAdjacentHTML('afterbegin', KAV_ICONS);
});

/** Icon markup helper for JS-rendered UI. */
function icon(name, cls = '') {
  return `<svg class="icon ${cls}" aria-hidden="true"><use href="#i-${name}"></use></svg>`;
}
