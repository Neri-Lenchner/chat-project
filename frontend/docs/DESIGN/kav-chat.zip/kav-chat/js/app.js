/* ============================================================
   KAV · Shared UI behaviour
   Prototype only — in the real app these map to
   components/, hooks and Redux thunks.
   ============================================================ */

const $  = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

/* ------------------------------------------------------------
   Demo switches — lets you preview error / loading / empty
   states without a server. Remove in production.
   ------------------------------------------------------------ */
const Demo = {
  get(flag) { return sessionStorage.getItem('demo:' + flag) === '1'; },
  set(flag, on) { sessionStorage.setItem('demo:' + flag, on ? '1' : '0'); },
};

function mountDemoPanel() {
  const el = document.createElement('div');
  el.className = 'demo';
  el.innerHTML = `
    <button class="demo__toggle" type="button" aria-expanded="false" aria-label="מצבי תצוגה">
      ${icon('sliders')}
    </button>
    <div class="demo__panel u-hidden">
      <p class="demo__title">מצבי תצוגה</p>
      <label class="demo__opt"><input type="checkbox" data-flag="error">   הדמיית שגיאת שרת</label>
      <label class="demo__opt"><input type="checkbox" data-flag="loading"> טעינה איטית</label>
      <label class="demo__opt"><input type="checkbox" data-flag="empty">   מצב ריק</label>
      <p class="demo__hint">כלי עזר לבדיקת העיצוב בלבד. לא חלק מהמוצר.</p>
    </div>`;
  document.body.appendChild(el);

  const panel  = $('.demo__panel', el);
  const toggle = $('.demo__toggle', el);

  toggle.addEventListener('click', () => {
    const open = panel.classList.toggle('u-hidden');
    toggle.setAttribute('aria-expanded', String(!open));
  });

  $$('input[data-flag]', el).forEach((input) => {
    input.checked = Demo.get(input.dataset.flag);
    input.addEventListener('change', () => {
      Demo.set(input.dataset.flag, input.checked);
      if (input.dataset.flag !== 'error') location.reload();
    });
  });
}

/* ------------------------------------------------------------
   Fake API — replaces axios in the prototype
   ------------------------------------------------------------ */
const api = {
  /**
   * @param {*} payload  value resolved on success
   * @param {string} errorMessage friendly Hebrew message on failure
   */
  call(payload, errorMessage = 'אירעה שגיאה. נסה שוב.') {
    const delay = Demo.get('loading') ? 2200 : 550;
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        if (Demo.get('error')) { reject(new Error(errorMessage)); return; }
        try { resolve(typeof payload === 'function' ? payload() : payload); }
        catch (err) { reject(err); }
      }, delay);
    });
  },
};

/* ------------------------------------------------------------
   Toasts
   ------------------------------------------------------------ */
function toast(message, variant = 'error') {
  let host = $('.toasts');
  if (!host) {
    host = document.createElement('div');
    host.className = 'toasts';
    host.setAttribute('role', 'status');
    host.setAttribute('aria-live', 'polite');
    document.body.appendChild(host);
  }

  const el = document.createElement('div');
  el.className = `toast toast--${variant}`;
  el.innerHTML = `
    ${icon(variant === 'success' ? 'check' : 'alert')}
    <span class="toast__text">${message}</span>
    <button class="toast__close" type="button" aria-label="סגירה">${icon('close', 'icon--sm')}</button>`;
  host.appendChild(el);

  const close = () => {
    el.classList.add('is-out');
    setTimeout(() => el.remove(), 220);
  };
  $('.toast__close', el).addEventListener('click', close);
  setTimeout(close, 5000);
}

/* ------------------------------------------------------------
   Confirm dialog (spec §8 — delete conversation)
   ------------------------------------------------------------ */
function confirmDialog({ title, text, confirmLabel = 'מחיקה', cancelLabel = 'ביטול', tone = 'danger' }) {
  return new Promise((resolve) => {
    const overlay = document.createElement('div');
    overlay.className = 'overlay';
    overlay.innerHTML = `
      <div class="dialog" role="dialog" aria-modal="true" aria-labelledby="dlg-title">
        <div class="dialog__art">${icon('trash')}</div>
        <h2 class="dialog__title" id="dlg-title">${title}</h2>
        <p class="dialog__text">${text}</p>
        <div class="dialog__actions">
          <button class="btn btn--secondary" data-act="cancel" type="button">${cancelLabel}</button>
          <button class="btn btn--${tone}" data-act="confirm" type="button">
            <span class="btn__icon">${icon('trash', 'icon--sm')}</span>${confirmLabel}
          </button>
        </div>
      </div>`;
    document.body.appendChild(overlay);

    const confirmBtn = $('[data-act="confirm"]', overlay);
    confirmBtn.focus();

    const done = (value) => { document.removeEventListener('keydown', onKey); overlay.remove(); resolve(value); };
    const onKey = (e) => {
      if (e.key === 'Escape') done(false);
      if (e.key === 'Tab') {
        const items = $$('.dialog button', overlay);
        const i = items.indexOf(document.activeElement);
        e.preventDefault();
        items[(i + (e.shiftKey ? -1 : 1) + items.length) % items.length].focus();
      }
    };

    overlay.addEventListener('click', (e) => { if (e.target === overlay) done(false); });
    $('[data-act="cancel"]', overlay).addEventListener('click', () => done(false));
    confirmBtn.addEventListener('click', () => done(true));
    document.addEventListener('keydown', onKey);
  });
}

/* ------------------------------------------------------------
   Form validation helpers (spec §17)
   ------------------------------------------------------------ */
const Validate = {
  required(value) {
    return value.trim() ? null : 'שדה חובה.';
  },
  name(value, label) {
    const v = value.trim();
    if (!v) return `יש להזין ${label}.`;
    if (v.length < 2) return `${label} חייב להכיל לפחות שתי אותיות.`;
    return null;
  },
  phone(value) {
    const v = value.trim();
    if (!v) return 'יש להזין מספר טלפון.';
    if (!/^\d+$/.test(v)) return 'מספר טלפון מכיל ספרות בלבד.';
    if (!/^0(5\d|[2-4]|[89]|7\d)\d{7}$/.test(v)) return 'מספר הטלפון אינו תקין. לדוגמה: 0501234567';
    return null;
  },
};

function setFieldError(input, message) {
  const field = input.closest('.field');
  const box = $('.field__error', field);
  if (message) {
    field.dataset.invalid = 'true';
    input.setAttribute('aria-invalid', 'true');
    box.innerHTML = `${icon('alert', 'icon--sm')}<span>${message}</span>`;
  } else {
    delete field.dataset.invalid;
    input.removeAttribute('aria-invalid');
    box.textContent = '';
  }
  return !message;
}

function showBanner(host, { title, text, variant = 'error' }) {
  host.innerHTML = `
    <div class="banner banner--${variant}" role="alert">
      ${icon(variant === 'error' ? 'alert' : 'info')}
      <span class="banner__body">
        <span class="banner__title">${title}</span>
        ${text ? `<span class="banner__text">${text}</span>` : ''}
      </span>
    </div>`;
  host.classList.remove('u-hidden');
}

function clearBanner(host) {
  host.innerHTML = '';
  host.classList.add('u-hidden');
}

/** Loading state on a button; blocks double submit (spec §15). */
function setLoading(btn, loading) {
  btn.dataset.loading = String(loading);
  btn.disabled = loading;
  btn.setAttribute('aria-busy', String(loading));
}

/* ------------------------------------------------------------
   App shell
   ------------------------------------------------------------ */
const Shell = {
  /** Renders the navigation rail (spec §7.1 — menu). */
  rail(active) {
    const user = Store.getUser();
    const name = fullName(user) || 'אורח';
    return `
      <nav class="rail" aria-label="ניווט ראשי">
        <a class="rail__logo" href="home.html" aria-label="קו — דף הבית">
          <span class="mark"><i></i><i></i><i></i><i></i></span>
        </a>
        <a class="rail__btn" href="home.html" data-tip="שיחות"
           ${active === 'home' ? 'aria-current="page"' : ''}>${icon('chats')}</a>
        <a class="rail__btn" href="new-chat.html" data-tip="שיחה חדשה"
           ${active === 'new' ? 'aria-current="page"' : ''}>${icon('plus')}</a>
        <span class="spacer"></span>
        <span class="rail__divider"></span>
        <a class="rail__btn" href="#" data-tip="${name}" aria-label="${name}">
          <span class="avatar avatar--sm" data-chip="${chipOf(name)}">${initials(name)}</span>
        </a>
        <button class="rail__btn rail__btn--danger" type="button" data-logout data-tip="התנתקות" aria-label="התנתקות">
          ${icon('logout', 'icon--flip')}
        </button>
      </nav>`;
  },

  /** Mounts the rail, wires logout, guards the route. */
  mount(active) {
    const host = $('[data-rail]');
    if (host) host.outerHTML = this.rail(active);

    const logout = $('[data-logout]');
    if (logout) {
      logout.addEventListener('click', async () => {
        const ok = await confirmDialog({
          title: 'להתנתק מהחשבון?',
          text: 'השיחות וההודעות יימחקו מהמכשיר. תוכל להתחבר שוב עם מספר הטלפון שלך.',
          confirmLabel: 'התנתקות',
        });
        if (!ok) return;
        Store.clear();                       // spec §21 — reset all state
        location.href = 'login.html';
      });
    }
  },

  /** Redirects to login when there is no user in localStorage (spec §4). */
  guard() {
    const user = Store.getUser();
    if (!user) { location.replace('login.html'); return null; }
    return user;
  },
};

document.addEventListener('DOMContentLoaded', () => {
  if (!document.body.hasAttribute('data-no-demo')) mountDemoPanel();
});
