/* ============================================================
   KAV · Prototype data layer
   ------------------------------------------------------------
   Stands in for axios + Redux in the HTML prototype.
   In the real app: api/*.ts + store/*Slice.ts.
   ============================================================ */

/* ---------- Mock "server" ----------------------------------- */

const REGISTERED_PHONE = '0501234567';   // the only phone that can log in

const MOCK_CONTACTS = [
  { id: 21, firstName: 'יוסי',  lastName: 'כהן',    phone: '0521111111' },
  { id: 22, firstName: 'דני',   lastName: 'לוי',     phone: '0522222222' },
  { id: 23, firstName: 'משה',   lastName: 'ישראלי',  phone: '0523333333' },
  { id: 24, firstName: 'נועה',  lastName: 'ברק',     phone: '0524444444' },
  { id: 25, firstName: 'תמר',   lastName: 'שלו',     phone: '0525555555' },
  { id: 26, firstName: 'אבי',   lastName: 'מזרחי',   phone: '0526666666' },
  { id: 27, firstName: 'רונית', lastName: 'אלון',    phone: '0527777777' },
  { id: 28, firstName: 'איתי',  lastName: 'גל',      phone: '0528888888' },
];

const mins = (n) => Date.now() - n * 60000;
const days = (n) => Date.now() - n * 86400000;

const MOCK_ROOMS = [
  { id: 101, otherUserId: 21, name: 'יוסי כהן',   lastMessage: 'מעולה, נתראה מחר בעשר',        lastMessageAt: mins(4),        unread: 2 },
  { id: 102, otherUserId: 24, name: 'נועה ברק',   lastMessage: 'שלחתי לך את הקובץ',            lastMessageAt: mins(52),       unread: 0 },
  { id: 103, otherUserId: 22, name: 'דני לוי',     lastMessage: 'תודה רבה!',                    lastMessageAt: mins(320),      unread: 0 },
  { id: 104, otherUserId: 25, name: 'תמר שלו',     lastMessage: 'את הפגישה נזיז ליום שלישי',    lastMessageAt: days(1) + 3e6,  unread: 5 },
  { id: 105, otherUserId: 23, name: 'משה ישראלי',  lastMessage: 'בסדר גמור, מטפל בזה',          lastMessageAt: days(4),        unread: 0 },
];

const MOCK_MESSAGES = {
  101: [
    { id: 1, content: 'היי יוסי, יצא לך להסתכל על האפיון?', mine: true,  sentAt: days(1) + 36e5 },
    { id: 2, content: 'כן, עברתי עליו הבוקר. נראה מסודר',   mine: false, sentAt: days(1) + 37e5 },
    { id: 3, content: 'יש לי שתי הערות על מסך ההרשמה',      mine: false, sentAt: days(1) + 37.2e5 },
    { id: 4, content: 'מעולה, בוא נדבר על זה מחר',           mine: true,  sentAt: mins(240) },
    { id: 5, content: 'מתאים לך בעשר במשרד?',                mine: false, sentAt: mins(12) },
    { id: 6, content: 'מעולה, נתראה מחר בעשר',               mine: false, sentAt: mins(4) },
  ],
  102: [
    { id: 1, content: 'נועה, את צריכה את הקובץ של אתמול?', mine: true,  sentAt: mins(120) },
    { id: 2, content: 'שלחתי לך את הקובץ',                 mine: false, sentAt: mins(52) },
  ],
  103: [
    { id: 1, content: 'סגרתי את הבאג בטופס',  mine: true,  sentAt: mins(400) },
    { id: 2, content: 'תודה רבה!',            mine: false, sentAt: mins(320) },
  ],
  104: [
    { id: 1, content: 'תמר, מה קורה עם הפגישה של שני?',   mine: true,  sentAt: days(1) + 2.4e6 },
    { id: 2, content: 'את הפגישה נזיז ליום שלישי',        mine: false, sentAt: days(1) + 3e6 },
  ],
  105: [
    { id: 1, content: 'משה, אפשר לקבל גישה לשרת?', mine: true,  sentAt: days(4) - 6e5 },
    { id: 2, content: 'בסדר גמור, מטפל בזה',        mine: false, sentAt: days(4) },
  ],
};

/* ---------- Store (localStorage-backed) --------------------- */

const Store = {
  /* --- session (spec §4) --- */
  getUser() {
    try { return JSON.parse(localStorage.getItem('user')); }
    catch { return null; }
  },
  setUser(user) { localStorage.setItem('user', JSON.stringify(user)); },
  clear() {
    localStorage.removeItem('user');
    localStorage.removeItem('rooms');
    localStorage.removeItem('messages');
  },

  /* --- rooms --- */
  getRooms() {
    const raw = localStorage.getItem('rooms');
    if (raw) { try { return JSON.parse(raw); } catch { /* fall through */ } }
    localStorage.setItem('rooms', JSON.stringify(MOCK_ROOMS));
    return [...MOCK_ROOMS];
  },
  setRooms(rooms) { localStorage.setItem('rooms', JSON.stringify(rooms)); },

  /* --- messages --- */
  getMessages(roomId) {
    const all = this.getAllMessages();
    return all[roomId] || [];
  },
  getAllMessages() {
    const raw = localStorage.getItem('messages');
    if (raw) { try { return JSON.parse(raw); } catch { /* fall through */ } }
    localStorage.setItem('messages', JSON.stringify(MOCK_MESSAGES));
    return { ...MOCK_MESSAGES };
  },
  addMessage(roomId, message) {
    const all = this.getAllMessages();
    all[roomId] = [...(all[roomId] || []), message];
    localStorage.setItem('messages', JSON.stringify(all));
  },
  dropMessages(roomId) {
    const all = this.getAllMessages();
    delete all[roomId];
    localStorage.setItem('messages', JSON.stringify(all));
  },
};

/* ---------- Formatting (spec §7.2) --------------------------- */

const pad = (n) => String(n).padStart(2, '0');

/** Today → time only. Otherwise → DD/MM/YYYY. */
function formatRoomTime(ts) {
  const d = new Date(ts);
  const now = new Date();
  const sameDay =
    d.getDate() === now.getDate() &&
    d.getMonth() === now.getMonth() &&
    d.getFullYear() === now.getFullYear();
  return sameDay
    ? `${pad(d.getHours())}:${pad(d.getMinutes())}`
    : `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()}`;
}

function formatTime(ts) {
  const d = new Date(ts);
  return `${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

/** Day divider label: today / yesterday / date. */
function formatDayLabel(ts) {
  const d = new Date(ts);
  const now = new Date();
  const diff = Math.floor((now.setHours(0, 0, 0, 0) - new Date(ts).setHours(0, 0, 0, 0)) / 86400000);
  if (diff === 0) return 'היום';
  if (diff === 1) return 'אתמול';
  return `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()}`;
}

function dayKey(ts) {
  const d = new Date(ts);
  return `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;
}

/* ---------- Display helpers ---------------------------------- */

function initials(name = '') {
  return name.trim().split(/\s+/).slice(0, 2).map((w) => w[0]).join('');
}

/** Deterministic avatar chip (1–6) from a name. */
function chipOf(name = '') {
  let sum = 0;
  for (const ch of name) sum += ch.charCodeAt(0);
  return (sum % 6) + 1;
}

function fullName(user) {
  return user ? `${user.firstName} ${user.lastName}`.trim() : '';
}
